use hr;
###1
select first_name as First_Name ,last_name as Last_Name from employees;
###2
select distinct department_id from employees;
###3
select * from employees
order by first_name desc;
###4
SELECT first_name, last_name, salary, salary*0.15 as PF 
	FROM employees;
###5
select employee_ID,first_name, last_name, salary 
from employees
ORDER BY SALARY ASC;

--- 6 ---

 SELECT SUM(SALARY)
 FROM EMPLOYEES;
 
 ----- 7 ----
 SELECT MAX(SALARY) , MIN(SALARY) FROM EMPLOYEES;
 --- 8 ---
 select avg(salary),count(salary) from employees;
 ---- 9 ----
 select count(*) from employees;
 --- 10 ---
 select count(distinct job_id) from employees;
 --- 11 ---
 select upper(first_name) from employees;
 --- 12---
 select substring(first_name,1,3) from employees;
 --- 13---
 select trim(first_name) from employees;
--- 14---

SELECT first_name,last_name, LENGTH(first_name)+LENGTH(last_name) AS Length_of_Names 
    FROM employees;
--- 15 ---
SELECT * 
   FROM employees 
   WHERE  first_name REGEXP  '[0-9]';
   --- 16 ---
   SELECT first_name, last_name, salary
FROM employees
WHERE salary NOT BETWEEN 10000 AND 15000;

--- 17 ---

SELECT first_name, last_name, department_id
FROM employees
WHERE department_id = 30 OR department_id = 100
ORDER BY  department_id  ASC;

--- 18 ---
SELECT first_name, last_name, salary,department_id from employees
where salary not in(10000,15000)
and department_id in(30,100);

--- 19 ---
SELECT first_name, last_name, hire_date 
FROM employees 
WHERE YEAR(hire_date)  LIKE '1987%';

--- 20 --- --- Write a query to display the first_name of all employees who have both "b" and "c" in their first name

select first_name from employees
where first_name like '%b%'
and first_name like '%c%';

--- 21 --- Write a query to display the last name, job, and salary for all employees whose job is that of a 
--- Programmer or a Shipping Clerk, and whose salary is not equal to $4,500, $10,000, or $15,000

SELECT last_name, job_id, salary
FROM employees
WHERE job_id IN ('IT_PROG', 'SH_CLERK')
AND salary NOT IN (4500,10000, 15000);

--- 22 ---Write a query to display the last name of employees whose names have exactly 6 characters

SELECT last_name FROM employees WHERE last_name LIKE '______';

--- 23 --- Write a query to display the last name of employees having 'e' as the third character

SELECT last_name FROM employees WHERE last_name LIKE '__e%';

--- 24 --- Write a query to get the job_id and related employee's id
--- Partial output of the query :

SELECT job_id, GROUP_CONCAT(employee_id, ' ')  'Employees ID' 
FROM employees GROUP BY job_id;

--- 25 ---. Write a query to update the portion of the phone_number in the employees table, within the phone 
--- number the substring '124' will be replaced by '999
SET SQL_SAFE_UPDATES = 0;
UPDATE employees
SET phone_number = REPLACE(phone_number, '124', '999')
WHERE phone_number LIKE '%124%';
--- 26 ---  Write a query to get the details of the employees where the length of the first name greater than or 
--- equal to 8
SELECT * 
FROM employees
WHERE LENGTH(first_name) >= 8;
--- 27 ---

UPDATE employees SET email = CONCAT(email,'@gmail.com');











